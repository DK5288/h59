var data = {
	gameMainScene : -1,
	gamePlayerNode : -1,
	gameBGNode : -1,
	gameInfoNode : -1,
	curScene : null,
    testString : "游戏过程中的数据"
};

module.exports = data;